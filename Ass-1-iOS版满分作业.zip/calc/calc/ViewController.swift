//
//  ViewController.swift
//  calc
//
//  Created by Zhuqiang Ren on 2020/4/5.
//  Copyright © 2020 Zhuqiang Ren. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var display: UILabel!
    
    @IBOutlet var numKeys: [UIButton]!
    
    var currentValue: Decimal = 0
    var displayValue: Decimal = 0
    var decimalValue: Decimal = 1
    var nums: [Decimal] = []
    var ops: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func show(_ value: Decimal) {
        let intValue = NSDecimalNumber(decimal: value).intValue
        
        if abs(intValue) >= 100000000 {
            let f = NumberFormatter()
            f.maximumFractionDigits = 4
            f.numberStyle = .scientific
            display.text = f.string(from: NSDecimalNumber(decimal: value))!
        } else if value.isEqual(to: Decimal(intValue)) {
            display.text = String(intValue)
        } else {
            var strValue: String = "\(value)"
            if strValue.count > 9 {
                strValue = String(strValue.prefix(9))
            }
            display.text = strValue.trimmingCharacters(in:  CharacterSet(charactersIn: "."))
        }
        displayValue = value
    }
    
    func calcCurrentValue(_ n: Int) {
        let limit: Decimal = 10000000
        if abs(currentValue) < limit {
            currentValue *= 10
            if currentValue >= 0 {
                currentValue += Decimal(n)
            } else {
                currentValue -= Decimal(n)
            }
            
            var text = display.text!
            if text.contains(".") && n == 0 && (
                Float(text)!.isEqual(to: 0) || !currentValue.isEqual(to: 0)
                ) {
                text += "0"
                display.text = text
            } else {
                show(currentValue / decimalValue)
            }
            
            if decimalValue > 1 {
                decimalValue *= 10
            }
        }
        print(nums, ops)
    }
    
    func calcOperator(_ op: String) {
        nums.append(displayValue)
        currentValue = 0
        decimalValue = 1
        
        if ops.count != 0 && comparePriority(ops[ops.count-1], op) {
            while ops.count != 0 {
                calc(&nums, &ops)
            }
            show(nums[nums.count-1])
        }
        ops.append(op)
        print(nums, ops)
    }
    
    func comparePriority(_ op1: String, _ op2: String) -> Bool {
        return ["*", "/"].contains(op1) || ["+", "-"].contains(op2)
    }

    func calc(_ nums: inout [Decimal], _ ops: inout [String]) {
        let n2 = nums.popLast()
        let n1 = nums.popLast()
        let op = ops.popLast()
        nums.append(eval(n1!, n2!, op!))
    }

    func eval(_ n1: Decimal, _ n2: Decimal, _ op: String) -> Decimal {
        switch op {
        case "*":
            return n1 * n2
        case "/":
            return n1 / n2
        case "+":
            return n1 + n2
        case "-":
            return n1 - n2
        default:
            return 0
        }
    }
    @IBAction func key00Tapped(_ sender: Any) {
        calcCurrentValue(0)
        calcCurrentValue(0)
    }
    @IBAction func key0Tapped(_ sender: Any) {
        calcCurrentValue(0)
    }
    @IBAction func key1Tapped(_ sender: Any) {
        calcCurrentValue(1)
    }
    @IBAction func key2Tapped(_ sender: Any) {
        calcCurrentValue(2)
    }
    @IBAction func key3Tapped(_ sender: Any) {
        calcCurrentValue(3)
    }
    @IBAction func key4Tapped(_ sender: Any) {
        calcCurrentValue(4)
    }
    @IBAction func key5Tapped(_ sender: Any) {
        calcCurrentValue(5)
    }
    @IBAction func key6Tapped(_ sender: Any) {
        calcCurrentValue(6)
    }
    @IBAction func key7Tapped(_ sender: Any) {
        calcCurrentValue(7)
    }
    @IBAction func key8Tapped(_ sender: Any) {
        calcCurrentValue(8)
    }
    @IBAction func key9Tapped(_ sender: Any) {
        calcCurrentValue(9)
    }
    
    @IBAction func keyPlusTapped(_ sender: Any) {
        calcOperator("+")
    }
    @IBAction func keyMinusTapped(_ sender: Any) {
        calcOperator("-")
    }
    @IBAction func keyTimesTapped(_ sender: Any) {
        calcOperator("*")
    }
    @IBAction func keyDivisionTapped(_ sender: Any) {
        calcOperator("/")
    }
    @IBAction func keyEqualTapped(_ sender: Any) {
        nums.append(displayValue)
        currentValue = 0
        while ops.count != 0 {
            calc(&nums, &ops)
        }
        show(nums[nums.count-1])
        nums = []
        decimalValue = 1
    }
    @IBAction func keyCTapped(_ sender: Any) {
        currentValue = 0
        displayValue = 0
        nums = []
        ops = []
        decimalValue = 1
        show(0)
    }
    @IBAction func keySignTapped(_ sender: Any) {
        currentValue = -currentValue
        displayValue = -displayValue
        decimalValue = 1
        show(displayValue)
    }
    @IBAction func keyPercentTapped(_ sender: Any) {
        currentValue = 0
        displayValue /= 100
        decimalValue = 1
        show(displayValue)
    }
    @IBAction func keyDotTapped(_ sender: Any) {
        var text = display.text!
        if !text.contains(".") {
            text += "."
            decimalValue = 10
        }
        display.text = text
    }
}

