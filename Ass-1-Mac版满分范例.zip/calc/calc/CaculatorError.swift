//
//  CaculatorError.swift
//  calc
//
//  Created by Po-Hao Chen on 2020/3/19.
//  Copyright © 2020 UTS. All rights reserved.
//

import Foundation

enum CaculatorError: Error {
    // Incomplete expression. Expected input of the form [number] [operator number ...]
    case incompleteExpression
    
    // Invalid number (e.g. String input or out of bound integer)
    case invalidNumber(invalidString: String)
    
    // Division by zero
    case divisionByZero
    
    // input exceed the maximum/minimum value of Integer type
    case integerOutOfBound(num1: Int, operation: String, num2: Int)
}
