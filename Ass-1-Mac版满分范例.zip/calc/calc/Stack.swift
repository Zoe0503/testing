//
//  Stack.swift
//  calc
//
//  Created by Po-Hao Chen on 2020/3/18.
//  Copyright © 2020 UTS. All rights reserved.
//

import Foundation

// Generic data structure whcih implements last in first out rule
struct Stack<Element> {
    var elements = [Element]()
    
    // add one element to the stack
    mutating func push(_ element: Element) {
        elements.append(element)
    }
    
    // remove and return the last element on the stack
    mutating func pop() -> Element {
        return elements.removeLast()
    }
    
    // return the reference of the last element on the stack
    func peek() -> Element? {
        return elements.last
    }
    
    // return the size of the stack
    func size() -> Int {
        return elements.count
    }
    
    // check whether there is element in the stack
    func isEmpty() -> Bool {
        return elements.isEmpty
    }
}
