//
//  Calculator.swift
//  calc
//
//  Created by Po-Hao Chen on 2020/3/18.
//  Copyright © 2020 UTS. All rights reserved.
//

import Foundation

class Calculator {
    var inputs: [String]
    // acceptable operators
    let operators: [String] = ["+", "-", "x", "/", "%"]
    
    // stores input for later evaluation
    var numberStack: Stack<Int>
    var operatorStack: Stack<String>
    
    init() {
        self.inputs = []
        self.numberStack = Stack<Int>()
        self.operatorStack = Stack<String>()
    }
    
    //evaluate through the inputs
    func evaluateAll() throws {
        for (index, input) in inputs.enumerated() {
            if index % 2 == 0 {
                // odd index in expression, must be number
                let num = try isNumber(input)
                // push number to stack
                numberStack.push(num)
            } else {
                // even index in expression, must be operator
                try isOperator(input)
                
                // process the operation if incoming operator holds lower or equal precedence
                // then the top element on the operator stack
                while !operatorStack.isEmpty()
                    && precedence(input) <= precedence(operatorStack.peek()!){
                    try numberStack.push(evaluate())
                }
                // push operator to stack
                operatorStack.push(input)
            }
        }
        
        // process all the rest operations
        while !operatorStack.isEmpty() {
            try numberStack.push(evaluate())
        }
    }

    // evaluate one set of operation
    func evaluate() throws -> Int {
        let second = numberStack.pop()
        let first = numberStack.pop()
        let operation = operatorStack.pop()
        
        switch operation {
        case "+":
            // result integer out of bound check
            let (result, outOfBound) = first.addingReportingOverflow(second)
            guard !outOfBound else {
                throw CaculatorError.integerOutOfBound(
                    num1: first,
                    operation: operation,
                    num2: second
                )
            }
            return result
        case "-":
            // result integer out of bound check
            let (result, outOfBound) = first.subtractingReportingOverflow(second)
            guard !outOfBound else {
                throw CaculatorError.integerOutOfBound(
                    num1: first,
                    operation: operation,
                    num2: second
                )
            }
            return result
        case "x":
            // result integer out of bound check
            let (result, outOfBound) = first.multipliedReportingOverflow(by: second)
            guard !outOfBound else {
                throw CaculatorError.integerOutOfBound(
                    num1: first,
                    operation: operation,
                    num2: second
                )
            }
            return result
        case "/":
            // division by zero check
            guard second != 0 else {
                throw CaculatorError.divisionByZero
            }
            return first / second
        case "%":
            // division by zero check
            guard second != 0 else {
                throw CaculatorError.divisionByZero
            }
            return first % second
        default:
            return 0
        }
    }
    
    func calculate(inputs: [String]) throws -> Int {
        // check whether the expression is valid
        if inputs.count % 2 == 0 {
            throw CaculatorError.incompleteExpression
        }
        self.inputs = inputs
        try evaluateAll()
        // the last element remain on the stack would be the result
        return numberStack.pop()
    }
    
    // check for valid operators
    func isOperator(_ s: String) throws {
        guard operators.contains(s) else {
            throw CaculatorError.incompleteExpression
        }
    }
    
    // check for valid numbers
    func isNumber(_ s: String) throws -> Int {
        guard let num = Int(s)else {
            throw CaculatorError.invalidNumber(invalidString: s)
        }
        return num
    }
    
    // uitlity function getting operator precedence
    func precedence(_ operation: String) -> Int {
        switch operation {
        case "+", "-":
            return 1
        case "x", "/", "%":
            return 2
        default:
            return -1
        }
    }
}
