//
//  main.swift
//  calc
//
//  Created by Jesse Clark on 12/3/18.
//  Copyright © 2018 UTS. All rights reserved.
//

import Foundation

var args = ProcessInfo.processInfo.arguments
args.removeFirst() // remove the name of the program

let calculator = Calculator()
do {
    let result = try calculator.calculate(inputs: args)
    print(result)
} catch let error as CaculatorError {
    // Handle the errors outside of the calculator class to ensure code reusability and extendibility
    switch error {
    case CaculatorError.divisionByZero:
        print("Division by zero")
    case CaculatorError.incompleteExpression:
        print("Incomplete expression. Expected input of the form [number] [operator number ...]")
    case CaculatorError.invalidNumber(let invalidString):
        print("Invalid number: \(invalidString)")
    case CaculatorError.integerOutOfBound(let num1, let operation, let num2):
        var isOverflow = true
        switch operation {
        case "+":
            if num1 < 0 && num2 < 0 {
                isOverflow = false
            }
        case "x":
            if (num1 > 0 && num2 < 0) || (num1 < 0 && num2 > 0) {
                isOverflow = false
            }
        case "-":
            if num1 < 0 && num2 > 0 {
                isOverflow = false
            }
        default:
            isOverflow = true
        }
        
        if isOverflow {
            print("Integer Overflow: \(num1) \(operation) \(num2) > \(Int.max)")
        } else {
            print("Integer Underflow: \(num1) \(operation) \(num2) < \(Int.min)")
        }
    }
    exit(EXIT_FAILURE)
} catch let error { // other unexpected errors
    print("Unexpected error\(error)")
    exit(EXIT_FAILURE)
}
